var express = require('express');
var app = express();
var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/users');

var mydata_schema = mongoose.Schema({
        firstName:String,
        lastName:String,
        UserName:String,
        password:String,
        location:String
    });

    app.listen(3000,function(){
        console.log("connectd on 3000");
    })

    var model_copy = mongoose.model('users', mydata_schema);

    model_copy.find(function(err,resp){
        console.log(resp);
    });