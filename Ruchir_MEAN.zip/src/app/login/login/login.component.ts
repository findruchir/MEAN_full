import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
      data :any = {};
      formSubmit(){
        if(this.data.username == "admin" && this.data.password == "admin"){
          console.log("Login Successfully");
          this._router.navigate(['/home']);
        }
        else{
          console.log("Not a valid Admin");
        }
      }    
  constructor(private _router : Router) { }

  ngOnInit() {
  }
  
}
